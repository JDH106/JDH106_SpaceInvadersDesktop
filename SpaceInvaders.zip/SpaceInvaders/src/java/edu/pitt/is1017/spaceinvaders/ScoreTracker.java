package edu.pitt.is1017.spaceinvaders;

import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.UUID;

import javax.swing.JOptionPane;

import java.util.Date;

public class ScoreTracker {
	User user;
	int currentScore;
	int highestScore;
	String gameID;
	int scoreType;
	int hit;
	//DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	//Date date = new Date();
	//System.out.println(dateFormat.format(date)); //2014/08/06 15:59:48
	int yourScore;
	int theirScore;
	String theirFName;
	String theirLName;
	String finalString = "";
	public ScoreTracker(User u){
		user = u;
		
		currentScore = 0;
		this.gameID = UUID.randomUUID().toString();
		DbUtilities db = new DbUtilities();
		String sql = "SELECT MAX(scoreValue) FROM finalscores WHERE fk_userID = " + user.getUserID() + ";";
		// db.executeQuery(sql);
		try{
			ResultSet rs = db.getResultSet(sql);
			if(rs.next()){
				this.highestScore = rs.getInt("MAX(scoreValue)");
				
			}
		}
		catch (Exception SQL){
			
		}
			
		
	}
	
	public void recordScore(int point){
		if(point == 1){
			this.currentScore += 1;
			hit = 1;
			
			
		}
		if(point == -1){
			this.currentScore -= 1;
			hit = 0;
			
		}
		
		java.util.Date utilDate = new Date();
		
		java.sql.Date date = new java.sql.Date(utilDate.getTime());
		DbUtilities db = new DbUtilities();
		String sql = "Insert INTO runningscores (scoreValue,fk_userID,gameID,scoreType,dateTimeEntered) VALUES ('" + this.currentScore + "', '" + user.getUserID() + "', '" + gameID + "', " + hit + ", CURRENT_TIMESTAMP);";	
		db.executeQuery(sql);
	}
	
	public void recordFinalScore(){
		java.util.Date utilDate = new Date();
		java.sql.Date date = new java.sql.Date(utilDate.getTime());
		DbUtilities db = new DbUtilities();
		String sql = "Insert INTO finalscores (scoreValue,fk_userID,gameID,dateTimeEntered) VALUES ('" + this.currentScore + "', '" + user.getUserID() + "', '" + gameID + "', CURRENT_TIMESTAMP);";
		db.executeQuery(sql);
	}
	
	public void printScores(){
		DbUtilities db = new DbUtilities();
		String sql = "SELECT scoreValue FROM finalscores WHERE fk_userID = '" + user.getUserID() + "' AND gameID = '" + gameID + "';";
		// db.executeQuery(sql);
		try{
			ResultSet rs = db.getResultSet(sql);
			if(rs.next()){
				yourScore = rs.getInt("scoreValue");
				
				JOptionPane.showMessageDialog(null, "Your Score: " + rs.getInt("scoreValue"), "Your Score: " + rs.getInt("scoreValue"), JOptionPane.OK_OPTION);
			}
		}
		catch (Exception SQL){
			
		}
	}
	
	public void printScores2(){
		String sql2 = "SELECT lastName, firstName, MAX(scoreValue) FROM finalscores JOIN users ON fk_userID = userID GROUP BY lastName, firstName ORDER BY MAX(scoreValue) DESC LIMIT 1;";
		DbUtilities db2 = new DbUtilities();
		try{
			
			ResultSet rs2 = db2.getResultSet(sql2);
			if(rs2.next()){
				
				
			}
		}
		catch (Exception SQL){
			
		}
	}
	

	public int getCurrentScore(){
		return currentScore;
	}
	public int getHighestScore(){
		return highestScore;
	}
        public String getGameID() {
                return gameID;
    }
	
}
