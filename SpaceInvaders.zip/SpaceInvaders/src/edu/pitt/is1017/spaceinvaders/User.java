package edu.pitt.is1017.spaceinvaders;

import java.sql.ResultSet;

import javax.swing.JOptionPane;

public class User {

	int userID;
	String lastName;
	String firstName;
	String email;
	String password;
	boolean loggedIn = false;
	
	public User(int inputUserID){
		DbUtilities db = new DbUtilities();
		String sql = "SELECT userID FROM users WHERE userID = '" + inputUserID + "';";
		db.executeQuery(sql);
		try{
			ResultSet rs = db.getResultSet(sql);
			if(rs.next()){
				userID = inputUserID;
			}
		}
		catch (Exception SQL){
			
		}
		
		this.userID	= inputUserID;	
	}
	
	public User(String inputEmail, String inputPassword){
		DbUtilities db = new DbUtilities();
		String sql = "SELECT * FROM users WHERE email = '" + inputEmail + "' AND password = MD5('" + inputPassword + "');";
			
	try{	
		ResultSet rs = db.getResultSet(sql);
		if(rs.next()){
			this.loggedIn = true;
			this.userID = rs.getInt("userID");
			this.email = inputEmail;
			this.password = inputPassword;
			this.lastName = rs.getString("lastName");
			this.firstName = rs.getString("firstName");
			
			
			
		}
		else{
			this.loggedIn = false;
			JOptionPane.showMessageDialog(null, "Invalid Username or Password", "Invalid Username or Password", JOptionPane.OK_OPTION);
		}
		
		
	}
	
	catch(Exception ex){
		
	}
		
	}
	
	
	public User(String inputLastName, String inputFirstName, String inputEmail, String inputPassword){
		DbUtilities db = new DbUtilities();
		String sql = "Insert INTO users (lastName,firstName,email,password) VALUES ('" + inputLastName + "', '" + inputFirstName + "', '" + inputEmail + "', MD5('" + inputPassword + "'));";
		db.executeQuery(sql);
		
		this.lastName = inputLastName;
		this.firstName = inputFirstName;
		this.email = inputEmail;
		this.password = inputPassword;
	}
	
	public void saveUserInfo(){
		this.lastName = getLastName();
		this.firstName = getFirstName();
		this.email = getEmail();
		this.password = getPassword();
		this.userID = getUserID();
		
		DbUtilities db = new DbUtilities();
		String sql = "UPDATE users SET lastName = " + lastName + ", firstName = " + firstName + ", email = " + email + ", password = MD5('" + password + "') WHERE userID = " + userID + ";";
		db.executeQuery(sql);
	}
	
	public int getUserID(){
		return userID;
	}
	public String getEmail(){
		return email;
	}
	
	public void setEmail(String e){
		this.email = e;
	}
	
	public String getFirstName(){
		return firstName;
	}
	
	public void setFirstName(String fName){
		this.firstName = fName;
	}
	
	public String getLastName(){
		return lastName;
	}
	
	public void setLastName(String lName){
		this.lastName = lName;
	}
	
	public String getPassword(){
		return password;
	}
	
	public void setPassword(String p){
		this.password = p;
	}
	
	public boolean getLoggedIn(){
		return loggedIn;
	}
	
	public void setLoggedIn(Boolean b){
		this.loggedIn = b;
	}
	
}
