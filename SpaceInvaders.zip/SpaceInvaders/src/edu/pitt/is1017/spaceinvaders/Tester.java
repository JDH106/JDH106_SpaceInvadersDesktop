package edu.pitt.is1017.spaceinvaders;

import java.sql.ResultSet;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DbUtilities db = new DbUtilities();
		String email = "jdh106@pitt.edu";
		String password = "world123";
		String sql = "SELECT email, password FROM users WHERE email = '" + email + "' AND password = '" + password + "';";
				
		//sql = sql + "VALUES('" + txtLastName.getText() + "', '" + txtFirstName.getText() + "', '" + txtEmail.getText() + "', '" + txtPassword.getText() + "');";
		
		db.executeQuery(sql);
		
	try{	
		ResultSet rs = db.getResultSet(sql);
		if(rs.next()){
			System.out.println("You have successfully logged in");
		}
		else{
			System.out.println("Invalid Username or Password");
		}
		
		
	
	
	}
	catch(Exception ex){
		
	}
	finally{
		db.closeConnection();
	}
	

	}
}
